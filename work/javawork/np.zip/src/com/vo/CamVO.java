package com.vo;

public class CamVO {
	String img_name;
	
	public CamVO() {
	}
	
	public CamVO(String img_name) {
		this.img_name = img_name;
	
	}
	
	public String toString() {
		return "CamVO [img_name=" + img_name + "]";
	}

	public String getImg_name() {
		return img_name;
	}

	public void setImg_name(String img_name) {
		this.img_name = img_name;
	}
	
	
	
	
	
}
