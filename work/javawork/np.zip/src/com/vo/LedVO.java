package com.vo;

public class LedVO {
	String led;
	public LedVO() {
	}
	public LedVO(String led, String btn) {
		this.led = led;
	}
	
	public String toString() {
		return "LedVO [led=" + led + "]";
	}
	
	
}
